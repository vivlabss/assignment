package com.samsung.biz;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.samsung.dao.UserDAO;
import com.samsung.vo.UserVO;

public class UpdateUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		if (session.getAttribute("user") == null) {
			response.sendRedirect("login.jsp");
		}
		
		// session 에서는 원래 user 정보 받아옴
		UserVO vo = new UserVO();
		vo = (UserVO) session.getAttribute("user");

		// form 에서 입력받아 넘어온 것들
		RequestDispatcher view = null;
		if(!request.getParameter("password1").equals(request.getParameter("password2"))) {
			String msg = " 불일치";
			request.setAttribute("msg", msg);
			view = request.getRequestDispatcher("updateUser.jsp");
		} else {
			vo.setPassword(request.getParameter("password1"));
			vo.setNickname(request.getParameter("nickname"));
			vo.setEmail(request.getParameter("email"));
			vo.setIntro(request.getParameter("intro"));
			
			UserDAO dao = new UserDAO();
			dao.updateUser(vo);
			
			session.setAttribute("user", vo);
			
			view = request.getRequestDispatcher("getBoardList");
		}
		view.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		doGet(request, response);
	}

}
