package com.samsung.biz.board.impl;

import java.sql.*;
import java.util.ArrayList;

import com.samsung.biz.board.vo.BoardVO;
import com.samsung.utils.JDBCUtils;

public class BoardDAO {

	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	private BoardVO board = null;
	
	public void addBoard(BoardVO vo) {
		try {
			conn = JDBCUtils.getConnection();
			
			String sql = "insert into board(seq, title, nickname, content, regdate, userid) " +
					"values( (select nvl(max(seq), 0)+1 from board), ?, ?, ?, sysdate, ?)";
			stmt = conn.prepareStatement(sql);
			
			stmt.setString(1, vo.getTitle());
			stmt.setString(2, vo.getNickname());
			stmt.setString(3, vo.getContent());
			stmt.setString(4, vo.getUserid());
			
			int c = stmt.executeUpdate();
			System.out.println("=====" + c + "개 정상 입력 되었습니다.");
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, stmt);
		}
	}

	public void updateBoard(BoardVO vo) {
		try {
			conn = JDBCUtils.getConnection();
			
			String sql = "update board set title=?, content=? where seq=?";
			stmt = conn.prepareStatement(sql);
			
			stmt.setString(1, vo.getTitle());
			stmt.setString(2, vo.getContent());
			stmt.setInt(3, vo.getSeq());
			
			int c = stmt.executeUpdate();
			System.out.println("=====" + c + "개 정상 수정 되었습니다.");
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, stmt);
		}
	}

	public void deleteBoard(BoardVO vo) {
		try {
			conn = JDBCUtils.getConnection();
			
			String sql = "delete from board where seq=?";
			stmt = conn.prepareStatement(sql);
			
			stmt.setInt(1, vo.getSeq());
			
			int c = stmt.executeUpdate();
			System.out.println("=====" + c + "개 정상 삭제 되었습니다.");
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, stmt);
		}
	}

	// ResultSet 값을 적절히 처리해서 넘겨야 한다.
	public BoardVO getBoard(BoardVO vo) {
		try {
			conn = JDBCUtils.getConnection();
			
			String sql = "select * from board where seq=?";
			stmt = conn.prepareStatement(sql);
			
			stmt.setInt(1, vo.getSeq());
			
			rs = stmt.executeQuery();
			
			if (rs.next()) {
				board = new BoardVO();
				board.setSeq(rs.getInt("seq"));
				board.setTitle(rs.getString("title"));
				board.setNickname(rs.getString("nickname"));
				board.setContent(rs.getString("content"));
				board.setRegdate(rs.getDate("regdate"));
				board.setCnt(rs.getInt("cnt"));
				board.setUserid(rs.getString("userid"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, stmt, rs);
		}
		
		return board;
	}

	// 모든 ResultSet 값을 적절히 처리해서 넘겨야 한다.
	public ArrayList<BoardVO> getBoardList(BoardVO vo) {
		
		ArrayList<BoardVO> list = new ArrayList<>();
		
		try {
			conn = JDBCUtils.getConnection();
			String sql = "";
			if(vo.getSearchCondition().equals("TITLE")) {
				sql = "select * from board where title like '%' || ? || '%' order by seq desc";				
			} else if (vo.getSearchCondition().equals("CONTENT")) {
				sql = "select * from board where content like '%' || ? || '%' order by seq desc";
			}
			
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, vo.getSearchKeyword());
			
			rs = stmt.executeQuery();
			
			while (rs.next()) {
				board = new BoardVO();
				board.setSeq(rs.getInt("seq"));
				board.setTitle(rs.getString("title"));
				board.setNickname(rs.getString("nickname"));
				board.setContent(rs.getString("content"));
				board.setRegdate(rs.getDate("regdate"));
				board.setCnt(rs.getInt("cnt"));
				board.setUserid(rs.getString("userid"));
				list.add(board);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(conn, stmt, rs);
		}
		
		return list;
	}
}
